import hashlib
import json
import random
import sqlite3
import tkinter as tk
from tkinter import filedialog, messagebox

import customtkinter as ctk
import jdatetime
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ---------------- Constants ----------------
BG = ("#f1f5f9", "#0b1020")
SURFACE = ("#ffffff", "#141b2d")
SURFACE2 = ("#e8edf5", "#1c2540")
INPUT = ("#f8fafc", "#0f1626")
BORDER = ("#d3dbe8", "#263150")
TEXT = ("#0f172a", "#e8ecf6")
MUTED = ("#64748b", "#8b96b0")
ACCENT, ACCENT_H = "#6366f1", "#4f46e5"
GREEN, RED, AMBER = "#22c55e", "#ef4444", "#f59e0b"
FONT = "Segoe UI"
DB_FILE = "smart_manager_v4.db"

MONTHS = ["Farvardin", "Ordibehesht", "Khordad", "Tir", "Mordad", "Shahrivar",
          "Mehr", "Aban", "Azar", "Dey", "Bahman", "Esfand"]
DAYS = ["Shanbeh", "Yekshanbeh", "Doshanbeh", "Seshanbeh", "Chaharshanbeh", "Panjshanbeh", "Jomeh"]
PRIORITY_EN = {"High": "high", "Medium": "medium", "Low": "low"}
PRIORITY_LABEL = {v: k for k, v in PRIORITY_EN.items()}
PRIORITY_COLOR = {"high": RED, "medium": AMBER, "low": GREEN}
EXPENSE_CATS = ["🍕 Food", "🚌 Transport", "🛒 Shopping", "🧾 Bills", "🏥 Health", "🎮 Fun", "📚 Education", "Other"]
INCOME_CATS = ["💼 Salary", "🎁 Gift", "📈 Investment", "Other"]
MOODS = {"😊": "happy", "😐": "neutral", "😢": "sad"}
MOOD_ICON = {v: k for k, v in MOODS.items()}
MOOD_COLOR = {"happy": GREEN, "neutral": AMBER, "sad": RED}
PIE_COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4", "#a855f7", "#ec4899", "#84cc16"]
QUOTES = ["Small steps every day beat one giant leap.", "Do something today your future self will thank you for.",
          "Focus means saying no to the unimportant.", "Small savings build big freedom.",
          "Start now; perfect can come later."]


# ---------------- Helpers ----------------
def parse_amount(s):
    s = str(s).replace(",", "").strip()
    try:
        v = float(s)
    except ValueError:
        return None
    return v if 0 < v < 1e15 else None


def parse_date(s):
    try:
        y, m, d = (int(x) for x in str(s).strip().replace("/", "-").split("-"))
        jdatetime.date(y, m, d)
    except Exception:
        return None
    return f"{y:04d}-{m:02d}-{d:02d}"


def dstr(t):
    return f"{t.year:04d}-{t.month:02d}-{t.day:02d}"


def today_str():
    return dstr(jdatetime.date.today())


def days_left(s):
    try:
        y, m, d = (int(x) for x in s.split("-"))
        return (jdatetime.date(y, m, d) - jdatetime.date.today()).days
    except Exception:
        return None


def recent_months(n):
    t = jdatetime.date.today()
    y, m, out = t.year, t.month, []
    for _ in range(n):
        out.append((f"{MONTHS[m - 1]} {y}", f"{y:04d}-{m:02d}"))
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return out


def fmt(n):
    return f"{n:,.0f}"


def compact(v):
    if abs(v) >= 1e6:
        return f"{v / 1e6:g}M"
    return f"{v / 1e3:g}k" if abs(v) >= 1e3 else f"{v:g}"


def new_salt():
    return f"{random.SystemRandom().getrandbits(128):032x}"


# ---------------- Database ----------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL, salt TEXT NOT NULL, pw_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, title TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'medium', category TEXT NOT NULL DEFAULT '',
    deadline TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending');
CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind TEXT NOT NULL, amount REAL NOT NULL, category TEXT NOT NULL,
    note TEXT NOT NULL DEFAULT '', date TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, title TEXT NOT NULL,
    target REAL NOT NULL, saved REAL NOT NULL DEFAULT 0, deadline TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, content TEXT NOT NULL,
    mood TEXT NOT NULL DEFAULT 'neutral', date TEXT NOT NULL, pinned INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS habits(id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS habit_logs(habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE,
    date TEXT NOT NULL, PRIMARY KEY(habit_id, date));
CREATE TABLE IF NOT EXISTS budgets(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category TEXT NOT NULL, limit_amount REAL NOT NULL, PRIMARY KEY(user_id, category));
CREATE TABLE IF NOT EXISTS prefs(key TEXT PRIMARY KEY, value TEXT);
"""
OWNED = ("tasks", "transactions", "goals", "notes", "habits")


class Database:
    def __init__(self, path=DB_FILE):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def q(self, sql, p=()):
        return self.conn.execute(sql, p).fetchall()

    def run(self, sql, p=()):
        cur = self.conn.execute(sql, p)
        self.conn.commit()
        return cur

    def delete(self, table, uid, rid):
        assert table in OWNED
        self.run(f"DELETE FROM {table} WHERE id=? AND user_id=?", (rid, uid))

    def get_pref(self, k, default=None):
        r = self.q("SELECT value FROM prefs WHERE key=?", (k,))
        return r[0]["value"] if r else default

    def set_pref(self, k, v):
        self.run("INSERT OR REPLACE INTO prefs(key,value) VALUES(?,?)", (k, str(v)))

    # users
    @staticmethod
    def _hash(pw, salt):
        return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()

    def register(self, u, p):
        salt = new_salt()
        try:
            return self.run("INSERT INTO users(username,salt,pw_hash) VALUES(?,?,?)",
                            (u, salt, self._hash(p, salt))).lastrowid
        except sqlite3.IntegrityError:
            return None

    def login(self, u, p):
        r = self.q("SELECT id,salt,pw_hash FROM users WHERE username=?", (u,))
        return r[0]["id"] if r and r[0]["pw_hash"] == self._hash(p, r[0]["salt"]) else None

    def change_password(self, uid, old, new):
        r = self.q("SELECT salt,pw_hash FROM users WHERE id=?", (uid,))
        if not r or r[0]["pw_hash"] != self._hash(old, r[0]["salt"]):
            return False
        salt = new_salt()
        self.run("UPDATE users SET salt=?,pw_hash=? WHERE id=?", (salt, self._hash(new, salt), uid))
        return True

    # tasks
    def add_task(self, uid, title, pr, cat, dl):
        self.run("INSERT INTO tasks(user_id,title,priority,category,deadline) VALUES(?,?,?,?,?)",
                 (uid, title, pr, cat, dl))

    def update_task(self, uid, tid, title, pr, cat, dl):
        self.run("UPDATE tasks SET title=?,priority=?,category=?,deadline=? WHERE id=? AND user_id=?",
                 (title, pr, cat, dl, tid, uid))

    def set_task_done(self, uid, tid, done):
        self.run("UPDATE tasks SET status=? WHERE id=? AND user_id=?", ("done" if done else "pending", tid, uid))

    def tasks(self, uid, status=None, search=""):
        sql, p = "SELECT * FROM tasks WHERE user_id=?", [uid]
        if status:
            sql += " AND status=?"
            p.append(status)
        if search:
            sql += " AND (title LIKE ? OR category LIKE ?)"
            p += [f"%{search}%"] * 2
        return self.q(sql + " ORDER BY status DESC, (deadline=''), deadline, id DESC", p)

    # transactions
    def add_tx(self, uid, kind, amount, cat, note, date):
        self.run("INSERT INTO transactions(user_id,kind,amount,category,note,date) VALUES(?,?,?,?,?,?)",
                 (uid, kind, amount, cat, note, date))

    def txs(self, uid, prefix=None):
        return self.q("SELECT * FROM transactions WHERE user_id=? AND date LIKE ? ORDER BY date DESC, id DESC",
                      (uid, (prefix or "") + "%"))

    def totals(self, uid, prefix=None):
        t = {"income": 0.0, "expense": 0.0}
        for r in self.q("SELECT kind, SUM(amount) s FROM transactions WHERE user_id=? AND date LIKE ? GROUP BY kind",
                        (uid, (prefix or "") + "%")):
            t[r["kind"]] = r["s"] or 0.0
        t["balance"] = t["income"] - t["expense"]
        return t

    def expense_by_cat(self, uid, prefix=None):
        return {r["category"]: r["s"] for r in self.q(
            "SELECT category, SUM(amount) s FROM transactions WHERE user_id=? AND kind='expense' "
            "AND date LIKE ? GROUP BY category ORDER BY s DESC", (uid, (prefix or "") + "%"))}

    # budgets
    def set_budget(self, uid, cat, limit):
        self.run("INSERT OR REPLACE INTO budgets(user_id,category,limit_amount) VALUES(?,?,?)", (uid, cat, limit))

    def budgets(self, uid):
        return {r["category"]: r["limit_amount"] for r in self.q("SELECT * FROM budgets WHERE user_id=?", (uid,))}

    # goals
    def add_goal(self, uid, title, target, dl):
        self.run("INSERT INTO goals(user_id,title,target,deadline) VALUES(?,?,?,?)", (uid, title, target, dl))

    def add_to_goal(self, uid, gid, amt):
        self.run("UPDATE goals SET saved=saved+? WHERE id=? AND user_id=?", (amt, gid, uid))

    def goals(self, uid):
        return self.q("SELECT * FROM goals WHERE user_id=? ORDER BY (saved>=target), id DESC", (uid,))

    # notes
    def add_note(self, uid, content, mood, date):
        self.run("INSERT INTO notes(user_id,content,mood,date) VALUES(?,?,?,?)", (uid, content, mood, date))

    def update_note(self, uid, nid, content, mood):
        self.run("UPDATE notes SET content=?,mood=? WHERE id=? AND user_id=?", (content, mood, nid, uid))

    def pin_note(self, uid, nid, pinned):
        self.run("UPDATE notes SET pinned=? WHERE id=? AND user_id=?", (int(pinned), nid, uid))

    def notes(self, uid, search=""):
        return self.q("SELECT * FROM notes WHERE user_id=? AND content LIKE ? ORDER BY pinned DESC, id DESC",
                      (uid, f"%{search}%"))

    # habits
    def add_habit(self, uid, name):
        self.run("INSERT INTO habits(user_id,name) VALUES(?,?)", (uid, name))

    def habits(self, uid):
        return self.q("SELECT * FROM habits WHERE user_id=? ORDER BY id", (uid,))

    def habit_days(self, hid):
        return {r["date"] for r in self.q("SELECT date FROM habit_logs WHERE habit_id=?", (hid,))}

    def toggle_habit(self, hid, date):
        if date in self.habit_days(hid):
            self.run("DELETE FROM habit_logs WHERE habit_id=? AND date=?", (hid, date))
        else:
            self.run("INSERT INTO habit_logs(habit_id,date) VALUES(?,?)", (hid, date))

    # export
    def export_all(self, uid):
        data = {n: [dict(r) for r in self.q(f"SELECT * FROM {n} WHERE user_id=?", (uid,))] for n in OWNED}
        data["budgets"] = [dict(r) for r in self.q("SELECT * FROM budgets WHERE user_id=?", (uid,))]
        return data

    def backup_to(self, dest):
        out = sqlite3.connect(dest)
        with out:
            self.conn.backup(out)
        out.close()


# ---------------- Widgets ----------------
def font(size=13, bold=False, **kw):
    return ctk.CTkFont(family=FONT, size=size, weight="bold" if bold else "normal", **kw)


def lbl(parent, text, size=13, bold=False, color=TEXT, **kw):
    return ctk.CTkLabel(parent, text=text, font=font(size, bold), text_color=color, **kw)


def card(parent, **kw):
    kw.setdefault("fg_color", SURFACE)
    kw.setdefault("corner_radius", 14)
    kw.setdefault("border_width", 1)
    kw.setdefault("border_color", BORDER)
    return ctk.CTkFrame(parent, **kw)


def entry(parent, width=180, placeholder=""):
    return ctk.CTkEntry(parent, width=width, height=36, placeholder_text=placeholder, font=font(13),
                        fg_color=INPUT, border_color=BORDER, text_color=TEXT,
                        placeholder_text_color=MUTED, corner_radius=10)


def menu(parent, values, variable, width=120, command=None):
    return ctk.CTkOptionMenu(parent, values=values, variable=variable, width=width, height=36,
                             font=font(13), dropdown_font=font(13), fg_color=INPUT, button_color=SURFACE2,
                             button_hover_color=BORDER, text_color=TEXT, dropdown_fg_color=SURFACE,
                             dropdown_text_color=TEXT, dropdown_hover_color=SURFACE2, command=command)


def button(parent, text, command=None, kind="primary", width=None, height=36):
    styles = {"primary": dict(fg_color=ACCENT, hover_color=ACCENT_H, text_color="white", border_width=0),
              "ghost": dict(fg_color="transparent", hover_color=SURFACE2, text_color=TEXT,
                            border_width=1, border_color=BORDER)}
    kw = dict(styles[kind])
    if width:
        kw["width"] = width
    return ctk.CTkButton(parent, text=text, command=command, height=height, corner_radius=10,
                         font=font(13, True), **kw)


def segmented(parent, values, command=None):
    s = ctk.CTkSegmentedButton(parent, values=values, command=command, font=font(13, True),
                               selected_color=ACCENT, selected_hover_color=ACCENT_H,
                               unselected_color=SURFACE2, text_color=TEXT)
    s.set(values[0])
    return s


def header(parent, title, subtitle=""):
    box = ctk.CTkFrame(parent, fg_color="transparent")
    box.pack(fill="x", pady=(0, 14))
    lbl(box, title, 24, True).pack(anchor="w")
    if subtitle:
        lbl(box, subtitle, 12, color=MUTED).pack(anchor="w")


def stat_card(parent, title, value, color):
    c = card(parent)
    lbl(c, title, 12, color=MUTED).pack(anchor="w", padx=16, pady=(12, 0))
    lbl(c, value, 19, True, color).pack(anchor="w", padx=16, pady=(2, 12))
    return c


def item_row(parent, **kw):
    r = card(parent, corner_radius=12, **kw)
    r.pack(fill="x", pady=4)
    inner = ctk.CTkFrame(r, fg_color="transparent")
    inner.pack(fill="x", padx=12, pady=9)
    return inner


def clear(w):
    for c in w.winfo_children():
        c.destroy()


def set_text(e, text):
    e.delete(0, "end")
    e.insert(0, text)


def mpl_colors():
    dark = ctk.get_appearance_mode() == "Dark"
    return dict(bg="#141b2d" if dark else "#ffffff", fg="#e8ecf6" if dark else "#0f172a",
                grid="#263150" if dark else "#e2e8f0")


def embed(fig, parent, bg):
    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()
    w = canvas.get_tk_widget()
    w.configure(bg=bg, highlightthickness=0)
    w.pack(fill="both", expand=True, padx=8, pady=8)


def draw_monthly_chart(parent, db, uid):
    months = recent_months(6)[::-1]
    inc, exp = [], []
    for _, prefix in months:
        t = db.totals(uid, prefix)
        inc.append(t["income"])
        exp.append(t["expense"])
    c = mpl_colors()
    fig = Figure(figsize=(5.4, 3.3), dpi=100, facecolor=c["bg"])
    ax = fig.add_subplot(111)
    ax.set_facecolor(c["bg"])
    x, w = list(range(len(months))), 0.38
    ax.bar([i - w / 2 for i in x], inc, w, color=GREEN, label="Income")
    ax.bar([i + w / 2 for i in x], exp, w, color=RED, label="Expense")
    ax.set_xticks(x)
    ax.set_xticklabels([label.split()[0] for label, _ in months])
    ax.tick_params(colors=c["fg"], labelsize=8, length=0)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: compact(v)))
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(c["grid"])
    ax.yaxis.grid(True, color=c["grid"], linewidth=0.6)
    ax.set_axisbelow(True)
    ax.legend(facecolor=c["bg"], edgecolor=c["grid"], labelcolor=c["fg"], fontsize=9)
    fig.tight_layout()
    embed(fig, parent, c["bg"])


def draw_pie(parent, data):
    lbl(parent, "Expense breakdown", 14, True).pack(anchor="w", padx=16, pady=(12, 0))
    if not data:
        lbl(parent, "No expenses yet", 13, color=MUTED).pack(pady=30)
        return
    c = mpl_colors()
    fig = Figure(figsize=(4, 3.2), dpi=100, facecolor=c["bg"])
    ax = fig.add_subplot(111)
    ax.pie(list(data.values()), labels=list(data), autopct="%1.0f%%", startangle=90,
           colors=PIE_COLORS[:len(data)], textprops={"color": c["fg"], "fontsize": 9},
           wedgeprops={"width": 0.45, "edgecolor": c["bg"]}, pctdistance=0.78)
    fig.tight_layout()
    embed(fig, parent, c["bg"])


# ---------------- App ----------------
NAV = [("dashboard", "📊  Dashboard"), ("tasks", "📋  Tasks"), ("habits", "🔥  Habits"),
       ("finance", "💰  Budget"), ("goals", "🎯  Goals"), ("notes", "📝  Notes"),
       ("focus", "⏱  Focus"), ("settings", "⚙️  Settings")]


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.db = Database()
        ctk.set_appearance_mode(self.db.get_pref("theme", "dark"))
        self.title("Smart Manager")
        self.geometry("1200x780")
        self.minsize(1000, 660)
        self.configure(fg_color=BG)
        self.user_id, self.username, self.current = None, "", "dashboard"
        self.nav_buttons, self.page_host, self.root_frame, self._toast = {}, None, None, None
        self.pomo = dict(total=1500, left=1500, running=False, job=None)
        self._pomo_lbl = None
        self.show_auth()

    def toast(self, msg, ok=True):
        if self._toast is not None:
            try:
                self._toast.destroy()
            except Exception:
                pass
        t = ctk.CTkLabel(self, text=f"   {msg}   ", font=font(13, True), text_color="white",
                         fg_color=GREEN if ok else RED, corner_radius=10, height=40)
        t.place(relx=0.5, rely=0.97, anchor="s")
        t.lift()
        self._toast = t

        def kill():
            try:
                t.destroy()
            except Exception:
                pass
        self.after(2600, kill)

    def confirm(self, text):
        return messagebox.askyesno("Confirm", text)

    def reset_root(self):
        if self.root_frame is not None:
            self.root_frame.destroy()
        self.root_frame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.root_frame.pack(fill="both", expand=True)

    # ----- Auth -----
    def show_auth(self, register=False):
        self.reset_root()
        wrap = ctk.CTkFrame(self.root_frame, fg_color="transparent")
        wrap.pack(expand=True)
        box = card(wrap, corner_radius=20)
        box.pack(padx=30, pady=30, ipadx=30, ipady=14)
        lbl(box, "🧠 Smart Manager", 26, True, ACCENT).pack(pady=(24, 4))
        lbl(box, "Tasks, habits, budget, goals and notes in one place", 12, color=MUTED).pack(pady=(0, 18))
        user_e = entry(box, 300, "Username")
        user_e.pack(pady=6, padx=30)
        pass_e = entry(box, 300, "Password")
        pass_e.configure(show="●")
        pass_e.pack(pady=6, padx=30)
        conf_e = None
        if register:
            conf_e = entry(box, 300, "Repeat password")
            conf_e.configure(show="●")
            conf_e.pack(pady=6, padx=30)
        msg = lbl(box, "", 12, color=RED)
        msg.pack(pady=(6, 0))

        def submit(_=None):
            u, p = user_e.get().strip(), pass_e.get()
            if not u or not p:
                return msg.configure(text="Fill in all fields")
            if register:
                if len(u) < 3 or len(p) < 6:
                    return msg.configure(text="Username min 3 chars, password min 6 chars")
                if p != conf_e.get():
                    return msg.configure(text="Passwords don't match")
                uid = self.db.register(u, p)
                if not uid:
                    return msg.configure(text="Username already taken")
            else:
                uid = self.db.login(u, p)
                if not uid:
                    return msg.configure(text="Wrong username or password")
            self.user_id, self.username, self.current = uid, u, "dashboard"
            self.show_shell()

        for e in (user_e, pass_e, conf_e):
            if e is not None:
                e.bind("<Return>", submit)
        button(box, "Sign up" if register else "Log in", submit, width=300, height=40).pack(pady=(14, 6), padx=30)
        button(box, "Have an account? Log in" if register else "No account? Sign up",
               lambda: self.show_auth(not register), "ghost", 300).pack(pady=(0, 20), padx=30)
        user_e.focus()

    def logout(self):
        if self.confirm("Log out?"):
            self.pomo_stop()
            self.user_id, self.username = None, ""
            self.show_auth()

    def show_shell(self):
        self.reset_root()
        side = ctk.CTkFrame(self.root_frame, width=220, corner_radius=0, fg_color=SURFACE)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)
        lbl(side, "🧠 Smart Manager", 17, True, ACCENT).pack(pady=(26, 2))
        lbl(side, f"👤 {self.username}", 12, color=MUTED).pack(pady=(0, 18))
        self.nav_buttons = {}
        for key, text in NAV:
            b = ctk.CTkButton(side, text=text, anchor="w", height=40, corner_radius=10, font=font(14, True),
                              fg_color="transparent", hover_color=SURFACE2, text_color=TEXT,
                              command=lambda k=key: self.navigate(k))
            b.pack(fill="x", padx=14, pady=2)
            self.nav_buttons[key] = b
        button(side, "🚪 Log out", self.logout, "ghost").pack(side="bottom", fill="x", padx=14, pady=18)
        self.page_host = ctk.CTkFrame(self.root_frame, fg_color="transparent")
        self.page_host.pack(side="right", fill="both", expand=True, padx=24, pady=20)
        self.navigate(self.current)

    def navigate(self, key):
        self.current = key
        for k, b in self.nav_buttons.items():
            b.configure(fg_color=ACCENT if k == key else "transparent",
                        text_color="white" if k == key else TEXT)
        clear(self.page_host)
        getattr(self, f"page_{key}")(self.page_host)

    # ===== Dashboard =====
    def page_dashboard(self, host):
        db, uid = self.db, self.user_id
        page = ctk.CTkScrollableFrame(host, fg_color="transparent")
        page.pack(fill="both", expand=True)
        t = jdatetime.date.today()
        header(page, f"Hello {self.username} 👋", f"{DAYS[t.weekday()]} {t.day} {MONTHS[t.month - 1]} {t.year}")
        lbl(page, "💡 " + random.choice(QUOTES), 12, color=MUTED).pack(anchor="w", pady=(0, 10))

        month = f"{t.year:04d}-{t.month:02d}"
        total, mon = db.totals(uid), db.totals(uid, month)
        pending = db.tasks(uid, status="pending")
        overdue = sum(1 for x in pending if x["deadline"] and x["deadline"] < today_str())
        habits = db.habits(uid)
        done_today = sum(1 for h in habits if today_str() in db.habit_days(h["id"]))

        row = ctk.CTkFrame(page, fg_color="transparent")
        row.pack(fill="x", pady=(0, 14))
        for title, val, color in (
                ("Total balance", f"{fmt(total['balance'])} Toman", ACCENT),
                ("Income this month", f"{fmt(mon['income'])} Toman", GREEN),
                ("Expense this month", f"{fmt(mon['expense'])} Toman", RED),
                ("Open tasks", f"{len(pending)}" + (f" ({overdue} overdue)" if overdue else ""), AMBER),
                ("Habits today", f"{done_today} of {len(habits)}", "#06b6d4")):
            stat_card(row, title, val, color).pack(side="left", expand=True, fill="x", padx=4)

        body = ctk.CTkFrame(page, fg_color="transparent")
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        chart = card(body)
        chart.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        lbl(chart, "Income & expense, last 6 months", 14, True).pack(anchor="w", padx=16, pady=(12, 0))
        draw_monthly_chart(chart, db, uid)

        right = ctk.CTkFrame(body, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        tc = card(right)
        tc.pack(fill="x", pady=(0, 10))
        lbl(tc, "🎯 Upcoming tasks", 14, True).pack(anchor="w", padx=16, pady=(12, 6))
        if pending:
            for x in pending[:5]:
                r = ctk.CTkFrame(tc, fg_color="transparent")
                r.pack(fill="x", padx=16, pady=3)
                late = x["deadline"] and x["deadline"] < today_str()
                lbl(r, "●", 12, color=PRIORITY_COLOR[x["priority"]]).pack(side="left")
                lbl(r, x["title"], 13).pack(side="left", padx=6)
                if x["deadline"]:
                    lbl(r, x["deadline"], 11, color=RED if late else MUTED).pack(side="right")
        else:
            lbl(tc, "🎉 No open tasks!", 13, color=GREEN).pack(pady=10)
        ctk.CTkFrame(tc, fg_color="transparent", height=8).pack()

        gc = card(right)
        gc.pack(fill="x")
        lbl(gc, "🏁 Active goals", 14, True).pack(anchor="w", padx=16, pady=(12, 6))
        active = [g for g in db.goals(uid) if g["saved"] < g["target"]][:3]
        for g in active:
            lbl(gc, g["title"], 12).pack(anchor="w", padx=16)
            bar = ctk.CTkProgressBar(gc, height=8, progress_color=ACCENT, fg_color=SURFACE2)
            bar.set(min(g["saved"] / g["target"], 1))
            bar.pack(fill="x", padx=16, pady=(2, 8))
        if not active:
            lbl(gc, "No goals yet", 13, color=MUTED).pack(pady=10)
        ctk.CTkFrame(gc, fg_color="transparent", height=6).pack()

    # ===== Tasks =====
    def page_tasks(self, host):
        db, uid = self.db, self.user_id
        header(host, "📋 Tasks", "Add, prioritize and check off")
        st = {"edit": None, "filter": "All"}
        status_map = {"All": None, "Pending": "pending", "Done": "done"}
        form = card(host)
        form.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(form, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=14)
        title_e = entry(row, 250, "Task title")
        title_e.pack(side="left", padx=4)
        prio = ctk.StringVar(value="Medium")
        menu(row, list(PRIORITY_EN), prio, 100).pack(side="left", padx=4)
        cat_e = entry(row, 130, "Category")
        cat_e.pack(side="left", padx=4)
        dl_e = entry(row, 120, "1405-07-15")
        dl_e.pack(side="left", padx=4)
        button(row, "📅", lambda: set_text(dl_e, today_str()), "ghost", 40).pack(side="left", padx=2)
        submit = button(row, "➕ Add", width=110)
        submit.pack(side="right", padx=4)
        cancel = button(row, "Cancel", kind="ghost", width=80)
        bar = ctk.CTkFrame(host, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 6))
        search = entry(bar, 260, "🔍 Search...")
        search.pack(side="left")
        segmented(bar, list(status_map), lambda v: (st.update(filter=v), refresh())).pack(side="right")
        box = ctk.CTkScrollableFrame(host, fg_color="transparent")
        box.pack(fill="both", expand=True)

        def reset_form():
            st["edit"] = None
            for e in (title_e, cat_e, dl_e):
                e.delete(0, "end")
            prio.set("Medium")
            submit.configure(text="➕ Add")
            cancel.pack_forget()

        def load_edit(t):
            st["edit"] = t["id"]
            set_text(title_e, t["title"])
            set_text(cat_e, t["category"])
            set_text(dl_e, t["deadline"])
            prio.set(PRIORITY_LABEL[t["priority"]])
            submit.configure(text="💾 Save")
            cancel.pack(side="right", padx=4)

        def save():
            title = title_e.get().strip()
            if not title:
                return self.toast("Enter a task title", False)
            dl = dl_e.get().strip()
            if dl:
                dl = parse_date(dl)
                if not dl:
                    return self.toast("Invalid date (example: 1405-07-15)", False)
            args = (title, PRIORITY_EN[prio.get()], cat_e.get().strip(), dl)
            if st["edit"]:
                db.update_task(uid, st["edit"], *args)
            else:
                db.add_task(uid, *args)
            reset_form()
            refresh()
            self.toast("Saved ✅")

        def toggle(tid, var):
            db.set_task_done(uid, tid, var.get())
            refresh()

        def remove(tid):
            if self.confirm("Delete this task?"):
                db.delete("tasks", uid, tid)
                if st["edit"] == tid:
                    reset_form()
                refresh()

        def refresh():
            clear(box)
            rows = db.tasks(uid, status_map[st["filter"]], search.get().strip())
            if not rows:
                lbl(box, "No tasks found", 14, color=MUTED).pack(pady=40)
            for t in rows:
                done = t["status"] == "done"
                late = (not done) and t["deadline"] and t["deadline"] < today_str()
                inner = item_row(box)
                var = tk.BooleanVar(value=done)
                ctk.CTkCheckBox(inner, text="", width=24, variable=var, fg_color=GREEN, hover_color=GREEN,
                                border_color=MUTED, command=lambda i=t["id"], v=var: toggle(i, v)).pack(side="left")
                ctk.CTkLabel(inner, text=t["title"], text_color=MUTED if done else TEXT,
                             font=ctk.CTkFont(family=FONT, size=14, weight="bold", overstrike=done)
                             ).pack(side="left", padx=8)
                ctk.CTkLabel(inner, text=f" {PRIORITY_LABEL[t['priority']]} ", font=font(11, True),
                             text_color="white", fg_color=PRIORITY_COLOR[t["priority"]],
                             corner_radius=8).pack(side="left", padx=4)
                if t["category"]:
                    lbl(inner, f"#{t['category']}", 12, color=MUTED).pack(side="left", padx=6)
                button(inner, "🗑", lambda i=t["id"]: remove(i), "ghost", 36, 32).pack(side="right", padx=2)
                button(inner, "✏️", lambda x=t: load_edit(x), "ghost", 36, 32).pack(side="right", padx=2)
                if t["deadline"]:
                    lbl(inner, ("⚠️ " if late else "📅 ") + t["deadline"], 12,
                        color=RED if late else MUTED).pack(side="right", padx=8)

        submit.configure(command=save)
        cancel.configure(command=reset_form)
        search.bind("<KeyRelease>", lambda e: refresh())
        refresh()

    # ===== Habits =====
    def page_habits(self, host):
        db, uid = self.db, self.user_id
        header(host, "🔥 Habits", "Check in every day and keep your streak alive")
        form = card(host)
        form.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(form, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=14)
        name_e = entry(row, 300, "Habit name (e.g. Read 30 minutes)")
        name_e.pack(side="left", padx=4)
        box = ctk.CTkScrollableFrame(host, fg_color="transparent")
        box.pack(fill="both", expand=True)

        def streak(days):
            d, n = jdatetime.date.today(), 0
            if dstr(d) not in days:
                d -= jdatetime.timedelta(days=1)
            while dstr(d) in days:
                n += 1
                d -= jdatetime.timedelta(days=1)
            return n

        def add():
            if not name_e.get().strip():
                return self.toast("Enter a habit name", False)
            db.add_habit(uid, name_e.get().strip())
            name_e.delete(0, "end")
            refresh()

        def toggle(hid, date):
            db.toggle_habit(hid, date)
            refresh()

        def remove(hid):
            if self.confirm("Delete this habit?"):
                db.delete("habits", uid, hid)
                refresh()

        def refresh():
            clear(box)
            hs = db.habits(uid)
            if not hs:
                lbl(box, "No habits yet 🔥", 14, color=MUTED).pack(pady=40)
            for h in hs:
                days = db.habit_days(h["id"])
                inner = item_row(box)
                lbl(inner, h["name"], 14, True).pack(side="left")
                lbl(inner, f"🔥 {streak(days)} days", 12, color=AMBER).pack(side="left", padx=12)
                button(inner, "🗑", lambda i=h["id"]: remove(i), "ghost", 36, 32).pack(side="right", padx=2)
                for i in range(7):
                    ds = dstr(jdatetime.date.today() - jdatetime.timedelta(days=i))
                    on = ds in days
                    ctk.CTkButton(inner, text="✔" if on else "·", width=30, height=30, corner_radius=8,
                                  fg_color=GREEN if on else SURFACE2, hover_color=ACCENT,
                                  text_color="white" if on else MUTED,
                                  command=lambda a=h["id"], b=ds: toggle(a, b)).pack(side="right", padx=2)

        button(row, "➕ Add", add, width=100).pack(side="left", padx=4)
        refresh()

    # ===== Budget =====
    def page_finance(self, host):
        db, uid = self.db, self.user_id
        header(host, "💰 Budget", "Track income and expenses, set monthly limits")
        form = card(host)
        form.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(form, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=14)
        kind = segmented(row, ["Expense", "Income"])
        kind.pack(side="left", padx=4)
        amount_e = entry(row, 130, "Amount (Toman)")
        amount_e.pack(side="left", padx=4)
        cat = ctk.StringVar(value=EXPENSE_CATS[0])
        cat_menu = menu(row, EXPENSE_CATS, cat, 140)
        cat_menu.pack(side="left", padx=4)
        date_e = entry(row, 110)
        date_e.insert(0, today_str())
        date_e.pack(side="left", padx=4)
        note_e = entry(row, 170, "Note (optional)")
        note_e.pack(side="left", padx=4)

        def on_kind(v):
            cats = EXPENSE_CATS if v == "Expense" else INCOME_CATS
            cat_menu.configure(values=cats)
            cat.set(cats[0])
        kind.configure(command=on_kind)

        months = recent_months(12)
        prefix_of = dict(months)
        flt = ctk.StringVar(value=months[0][0])
        bar = ctk.CTkFrame(host, fg_color="transparent")
        bar.pack(fill="x", pady=(0, 8))
        lbl(bar, "Period:", 12, color=MUTED).pack(side="left")
        menu(bar, ["All time"] + [m[0] for m in months], flt, 170,
             command=lambda v: refresh()).pack(side="left", padx=6)
        button(bar, "🎚 Set limit for selected category", lambda: set_limit(), "ghost", 260).pack(side="right")

        cards_row = ctk.CTkFrame(host, fg_color="transparent")
        cards_row.pack(fill="x", pady=(0, 8))
        body = ctk.CTkFrame(host, fg_color="transparent")
        body.pack(fill="both", expand=True)
        body.columnconfigure(0, weight=2)
        body.columnconfigure(1, weight=3)
        body.rowconfigure(0, weight=1)
        side = ctk.CTkScrollableFrame(body, fg_color=SURFACE, corner_radius=14, border_width=1, border_color=BORDER)
        side.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        list_box = ctk.CTkScrollableFrame(body, fg_color="transparent")
        list_box.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        def add():
            amount = parse_amount(amount_e.get())
            if not amount:
                return self.toast("Enter a valid amount", False)
            d = parse_date(date_e.get())
            if not d:
                return self.toast("Invalid date", False)
            db.add_tx(uid, "expense" if kind.get() == "Expense" else "income", amount, cat.get(),
                      note_e.get().strip(), d)
            amount_e.delete(0, "end")
            note_e.delete(0, "end")
            refresh()
            self.toast("Transaction saved 💰")

        def set_limit():
            if kind.get() != "Expense":
                return self.toast("Limits apply to expenses only", False)
            val = ctk.CTkInputDialog(text=f"Monthly limit for '{cat.get()}' (Toman):", title="Budget limit").get_input()
            amt = parse_amount(val) if val else None
            if not amt:
                return self.toast("Invalid amount", False)
            db.set_budget(uid, cat.get(), amt)
            refresh()

        def remove(tid):
            if self.confirm("Delete this transaction?"):
                db.delete("transactions", uid, tid)
                refresh()

        def refresh():
            prefix = prefix_of.get(flt.get())
            clear(cards_row)
            tot = db.totals(uid, prefix)
            for title, val, color in (("Balance", tot["balance"], ACCENT), ("Income", tot["income"], GREEN),
                                      ("Expense", tot["expense"], RED)):
                stat_card(cards_row, title, f"{fmt(val)} Toman", color).pack(side="left", expand=True,
                                                                             fill="x", padx=5)
            clear(side)
            draw_pie(side, db.expense_by_cat(uid, prefix))
            limits = db.budgets(uid)
            if limits:
                lbl(side, "🎚 Monthly limits", 13, True).pack(anchor="w", padx=14, pady=(6, 2))
            this_month = db.expense_by_cat(uid, months[0][1])
            for c_name, lim in limits.items():
                used = this_month.get(c_name, 0)
                pct = used / lim
                lbl(side, f"{c_name}: {fmt(used)} / {fmt(lim)}", 11,
                    color=RED if pct > 1 else MUTED).pack(anchor="w", padx=14)
                pb = ctk.CTkProgressBar(side, height=7, fg_color=SURFACE2,
                                        progress_color=RED if pct > 1 else AMBER if pct > .8 else GREEN)
                pb.set(min(pct, 1))
                pb.pack(fill="x", padx=14, pady=(2, 6))
            clear(list_box)
            txs = db.txs(uid, prefix)
            if not txs:
                lbl(list_box, "No transactions", 14, color=MUTED).pack(pady=40)
            for x in txs:
                inc = x["kind"] == "income"
                inner = item_row(list_box)
                lbl(inner, "⬆" if inc else "⬇", 16, True, GREEN if inc else RED).pack(side="left")
                col = ctk.CTkFrame(inner, fg_color="transparent")
                col.pack(side="left", padx=8)
                lbl(col, x["category"], 13, True).pack(anchor="w")
                lbl(col, x["date"] + (f"  •  {x['note']}" if x["note"] else ""), 11, color=MUTED).pack(anchor="w")
                button(inner, "🗑", lambda i=x["id"]: remove(i), "ghost", 36, 32).pack(side="right")
                lbl(inner, ("+" if inc else "-") + fmt(x["amount"]), 14, True,
                    GREEN if inc else RED).pack(side="right", padx=10)

        button(row, "💰 Save", add, width=90).pack(side="right", padx=4)
        refresh()

    # ===== Goals =====
    def page_goals(self, host):
        db, uid = self.db, self.user_id
        header(host, "🎯 Savings goals", "Save up for something you want")
        form = card(host)
        form.pack(fill="x", pady=(0, 10))
        row = ctk.CTkFrame(form, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=14)
        title_e = entry(row, 250, "Goal title (e.g. Laptop)")
        title_e.pack(side="left", padx=4)
        target_e = entry(row, 150, "Target (Toman)")
        target_e.pack(side="left", padx=4)
        dl_e = entry(row, 130, "Deadline (optional)")
        dl_e.pack(side="left", padx=4)
        box = ctk.CTkScrollableFrame(host, fg_color="transparent")

        def add():
            title, target = title_e.get().strip(), parse_amount(target_e.get())
            if not title or not target:
                return self.toast("Enter a title and a valid target", False)
            dl = dl_e.get().strip()
            if dl:
                dl = parse_date(dl)
                if not dl:
                    return self.toast("Invalid date", False)
            db.add_goal(uid, title, target, dl)
            for e in (title_e, target_e, dl_e):
                e.delete(0, "end")
            refresh()
            self.toast("Goal added 💪")

        def add_saving(gid):
            val = ctk.CTkInputDialog(text="How much (Toman) to add?", title="Add savings").get_input()
            amt = parse_amount(val) if val else None
            if not amt:
                return self.toast("Invalid amount", False)
            db.add_to_goal(uid, gid, amt)
            refresh()

        def remove(gid):
            if self.confirm("Delete this goal?"):
                db.delete("goals", uid, gid)
                refresh()

        def refresh():
            clear(box)
            goals = db.goals(uid)
            if not goals:
                lbl(box, "No goals yet 🎯", 14, color=MUTED).pack(pady=40)
            for g in goals:
                pct = g["saved"] / g["target"]
                c = card(box)
                c.pack(fill="x", pady=5)
                top = ctk.CTkFrame(c, fg_color="transparent")
                top.pack(fill="x", padx=16, pady=(12, 2))
                lbl(top, g["title"], 15, True).pack(side="left")
                if pct >= 1:
                    lbl(top, "✅ Completed", 12, True, GREEN).pack(side="right")
                elif g["deadline"]:
                    d = days_left(g["deadline"])
                    if d is not None:
                        lbl(top, "📅 " + (f"{d} days left" if d >= 0 else f"{-d} days overdue"), 12,
                            color=MUTED if d >= 0 else RED).pack(side="right")
                        if d > 0:
                            lbl(top, f"{fmt((g['target'] - g['saved']) / d)} per day", 11,
                                color=ACCENT).pack(side="right", padx=10)
                pb = ctk.CTkProgressBar(c, height=10, corner_radius=5, fg_color=SURFACE2,
                                        progress_color=GREEN if pct >= 1 else ACCENT)
                pb.set(min(pct, 1))
                pb.pack(fill="x", padx=16, pady=8)
                info = ctk.CTkFrame(c, fg_color="transparent")
                info.pack(fill="x", padx=16, pady=(0, 12))
                lbl(info, f"{fmt(g['saved'])} of {fmt(g['target'])} Toman  •  {pct * 100:.0f}%", 12,
                    color=MUTED).pack(side="left")
                button(info, "🗑", lambda i=g["id"]: remove(i), "ghost", 36, 32).pack(side="right", padx=2)
                if pct < 1:
                    button(info, "➕ Add savings", lambda i=g["id"]: add_saving(i), width=130,
                           height=32).pack(side="right", padx=2)

        button(row, "🎯 Add", add, width=90).pack(side="right", padx=4)
        box.pack(fill="both", expand=True)
        refresh()

    # ===== Notes =====
    def page_notes(self, host):
        db, uid = self.db, self.user_id
        header(host, "📝 Notes", "Write anything; pin the important ones")
        st = {"edit": None}
        form = card(host)
        form.pack(fill="x", pady=(0, 10))
        top = ctk.CTkFrame(form, fg_color="transparent")
        top.pack(fill="x", padx=14, pady=(14, 6))
        lbl(top, "Mood:", 12, color=MUTED).pack(side="left", padx=4)
        mood = segmented(top, list(MOODS))
        mood.pack(side="left", padx=4)
        tb = ctk.CTkTextbox(form, height=90, font=font(13), fg_color=INPUT, text_color=TEXT,
                            border_width=1, border_color=BORDER, corner_radius=10)
        tb.pack(fill="x", padx=14, pady=6)
        acts = ctk.CTkFrame(form, fg_color="transparent")
        acts.pack(fill="x", padx=14, pady=(0, 14))
        submit = button(acts, "💾 Save", width=110)
        submit.pack(side="left")
        cancel = button(acts, "Cancel", kind="ghost", width=80)
        search = entry(host, 280, "🔍 Search notes...")
        search.pack(anchor="w", pady=(0, 6))
        box = ctk.CTkScrollableFrame(host, fg_color="transparent")
        box.pack(fill="both", expand=True)

        def reset_form():
            st["edit"] = None
            tb.delete("1.0", "end")
            mood.set("😊")
            submit.configure(text="💾 Save")
            cancel.pack_forget()

        def load_edit(n):
            st["edit"] = n["id"]
            tb.delete("1.0", "end")
            tb.insert("1.0", n["content"])
            mood.set(MOOD_ICON[n["mood"]])
            submit.configure(text="💾 Save changes")
            cancel.pack(side="left", padx=6)

        def save():
            content = tb.get("1.0", "end-1c").strip()
            if not content:
                return self.toast("Write something first", False)
            if st["edit"]:
                db.update_note(uid, st["edit"], content, MOODS[mood.get()])
            else:
                db.add_note(uid, content, MOODS[mood.get()], today_str())
            reset_form()
            refresh()
            self.toast("Note saved ✅")

        def remove(nid):
            if self.confirm("Delete this note?"):
                db.delete("notes", uid, nid)
                if st["edit"] == nid:
                    reset_form()
                refresh()

        def pin(n):
            db.pin_note(uid, n["id"], not n["pinned"])
            refresh()

        def refresh():
            clear(box)
            notes = db.notes(uid, search.get().strip())
            if not notes:
                lbl(box, "No notes found", 14, color=MUTED).pack(pady=40)
            for n in notes:
                c = card(box, corner_radius=12, border_color=MOOD_COLOR[n["mood"]])
                c.pack(fill="x", pady=5)
                head = ctk.CTkFrame(c, fg_color="transparent")
                head.pack(fill="x", padx=14, pady=(10, 0))
                lbl(head, ("📌 " if n["pinned"] else "") + f"{MOOD_ICON[n['mood']]}  {n['date']}", 12,
                    color=MUTED).pack(side="left")
                button(head, "🗑", lambda i=n["id"]: remove(i), "ghost", 34, 30).pack(side="right", padx=2)
                button(head, "✏️", lambda x=n: load_edit(x), "ghost", 34, 30).pack(side="right", padx=2)
                button(head, "📌", lambda x=n: pin(x), "ghost", 34, 30).pack(side="right", padx=2)
                lbl(c, n["content"], 13, wraplength=700, justify="left").pack(anchor="w", padx=16, pady=(4, 12))

        submit.configure(command=save)
        cancel.configure(command=reset_form)
        search.bind("<KeyRelease>", lambda e: refresh())
        refresh()

    # ===== Focus (Pomodoro) =====
    def pomo_text(self):
        m, s = divmod(self.pomo["left"], 60)
        return f"{m:02d}:{s:02d}"

    def pomo_show(self):
        try:
            if self._pomo_lbl is not None and self._pomo_lbl.winfo_exists():
                self._pomo_lbl.configure(text=self.pomo_text())
        except tk.TclError:
            pass

    def pomo_stop(self):
        if self.pomo["job"]:
            self.after_cancel(self.pomo["job"])
        self.pomo.update(running=False, job=None)

    def pomo_tick(self):
        p = self.pomo
        if not p["running"]:
            return
        p["left"] -= 1
        if p["left"] <= 0:
            self.pomo_stop()
            p["left"] = p["total"]
            if p["total"] >= 1500 and self.user_id:
                key = f"pomo_{self.user_id}_{today_str()}"
                self.db.set_pref(key, int(self.db.get_pref(key, 0)) + 1)
            self.bell()
            self.toast("Time's up! 🎉")
            if self.current == "focus":
                self.navigate("focus")
        else:
            p["job"] = self.after(1000, self.pomo_tick)
            self.pomo_show()

    def page_focus(self, host):
        header(host, "⏱ Focus", "Pomodoro technique: deep work in short sprints")
        c = card(host)
        c.pack(pady=20, ipadx=60, ipady=20)
        done = int(self.db.get_pref(f"pomo_{self.user_id}_{today_str()}", 0))
        lbl(c, f"🍅 Sessions today: {done}", 13, color=MUTED).pack(pady=(14, 0))
        self._pomo_lbl = lbl(c, self.pomo_text(), 72, True, ACCENT)
        self._pomo_lbl.pack(padx=40, pady=10)
        options = {"25 min": 25, "5 min": 5, "15 min": 15}

        def choose(v):
            self.pomo_stop()
            self.pomo.update(total=options[v] * 60, left=options[v] * 60)
            self.pomo_show()

        seg = segmented(c, list(options), choose)
        seg.pack(pady=6)
        for label, mins in options.items():
            if self.pomo["total"] == mins * 60:
                seg.set(label)
        row = ctk.CTkFrame(c, fg_color="transparent")
        row.pack(pady=14)

        def start():
            if not self.pomo["running"]:
                self.pomo["running"] = True
                self.pomo["job"] = self.after(1000, self.pomo_tick)

        def reset():
            self.pomo_stop()
            self.pomo["left"] = self.pomo["total"]
            self.pomo_show()

        button(row, "▶ Start", start, width=100).pack(side="left", padx=4)
        button(row, "⏸ Pause", self.pomo_stop, "ghost", 100).pack(side="left", padx=4)
        button(row, "↺ Reset", reset, "ghost", 100).pack(side="left", padx=4)

    # ===== Settings =====
    def page_settings(self, host):
        header(host, "⚙️ Settings", "Appearance, security and backups")
        c1 = card(host)
        c1.pack(fill="x", pady=6)
        lbl(c1, "🎨 Appearance", 15, True).pack(anchor="w", padx=16, pady=(12, 6))
        seg = segmented(c1, ["Dark", "Light"], self.set_theme)
        seg.set("Dark" if ctk.get_appearance_mode() == "Dark" else "Light")
        seg.pack(anchor="w", padx=16, pady=(0, 14))

        c2 = card(host)
        c2.pack(fill="x", pady=6)
        lbl(c2, "🔒 Change password", 15, True).pack(anchor="w", padx=16, pady=(12, 6))
        row = ctk.CTkFrame(c2, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(0, 14))
        old_e, new_e, rep_e = entry(row, 170, "Current password"), entry(row, 170, "New password"), entry(row, 170, "Repeat new password")
        for e in (old_e, new_e, rep_e):
            e.configure(show="●")
            e.pack(side="left", padx=4)

        def change():
            if len(new_e.get()) < 6:
                return self.toast("New password must be at least 6 characters", False)
            if new_e.get() != rep_e.get():
                return self.toast("Passwords don't match", False)
            if not self.db.change_password(self.user_id, old_e.get(), new_e.get()):
                return self.toast("Current password is wrong", False)
            for e in (old_e, new_e, rep_e):
                e.delete(0, "end")
            self.toast("Password changed ✅")
        button(row, "Change", change, width=90).pack(side="left", padx=4)

        c3 = card(host)
        c3.pack(fill="x", pady=6)
        lbl(c3, "💾 Data", 15, True).pack(anchor="w", padx=16, pady=(12, 6))
        r3 = ctk.CTkFrame(c3, fg_color="transparent")
        r3.pack(fill="x", padx=16, pady=(0, 14))
        button(r3, "📤 Export JSON", self.export_json, "ghost", 150).pack(side="left", padx=4)
        button(r3, "🗄 Back up database", self.backup_db, "ghost", 180).pack(side="left", padx=4)

    def set_theme(self, value):
        mode = "dark" if value == "Dark" else "light"
        ctk.set_appearance_mode(mode)
        self.db.set_pref("theme", mode)
        self.after(80, lambda: self.navigate(self.current))

    def export_json(self):
        dest = filedialog.asksaveasfilename(defaultextension=".json", initialfile="smart_manager_export.json",
                                            filetypes=[("JSON", "*.json")])
        if dest:
            with open(dest, "w", encoding="utf-8") as f:
                json.dump(self.db.export_all(self.user_id), f, indent=2)
            self.toast("JSON exported ✅")

    def backup_db(self):
        dest = filedialog.asksaveasfilename(defaultextension=".db", initialfile="smart_manager_backup.db",
                                            filetypes=[("SQLite", "*.db")])
        if dest:
            self.db.backup_to(dest)
            self.toast("Backup saved ✅")


if __name__ == "__main__":
    App().mainloop()